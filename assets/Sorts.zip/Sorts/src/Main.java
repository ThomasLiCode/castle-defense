public class Main {
    public static void main(String[] args) {
        //Selection Sort
        System.out.println("Selection Sort");
        int[] arr1 = randomArray(7);
        printArr(arr1);
        System.out.println();
        selectionSort(arr1);
        printArr(arr1);
        //Insertion Sort
        System.out.println();
        System.out.println("Insertion Sort");
        int[] arr2 = randomArray(7);
        printArr(arr2);
        System.out.println();
        insertionSort(arr2);
        printArr(arr2);
        //Quick Sort
        System.out.println();
        System.out.println("Quick Sort");
        int[] arr3 = randomArray(7);
        printArr(arr3);
        System.out.println();
        quickSort(arr3, 0, arr3.length - 1);
        printArr(arr3);
        //Merge Sort
        System.out.println();
        System.out.println("Merge Sort");
        int[] arr4 = randomArray(7);
        printArr(arr4);
        System.out.println();
        mergeSort(arr4, 0, arr4.length - 1);
        printArr(arr4);
        //Bubble Sort
        System.out.println();
        System.out.println("Bubble Sort");
        int[] arr5 = randomArray(7);
        printArr(arr5);
        System.out.println();
        bubbleSort(arr5);
        printArr(arr5);



    }

    public static void swap(int[] arr, int a, int b){
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }

    public static void printArr(int[] arr){
        for(int i = 0; i<arr.length; i++){
            System.out.print(arr[i] + " ");
        }
    }

    public static int[] randomArray(int length){
        int[] arr = new int[length];
        for(int i = 0; i < length; i++){
            arr[i] = (int)(Math.random()*10);
        }
        return arr;
    }

    public static void selectionSort(int[] arr){
        for(int i = 0; i < arr.length; i++){
            int min = i;
            for(int j = i + 1; j < arr.length; j++){
                if(arr[j] < arr[min])
                    min = j;
            }
            swap(arr, i , min);
        }
    }

    public static void insertionSort(int[] arr){
        for(int i = 1; i<arr.length; i++){
            while(i - 1 >= 0 && arr[i - 1] > arr[i]){
                swap(arr, i , i - 1);
                i--;
            }
        }
    }

    public static void quickSort(int[] arr, int l, int r){
        if(l < r){
            int p = partition(arr, l, r);
            quickSort(arr, l, p - 1);
            quickSort(arr, p + 1, r);
        }
    }

    public static int partition(int[] arr, int l, int r){
        int pivot = arr[r];
        int small = l - 1;
        for(int i = l; i <= r - 1; i++){
            if(arr[i] < pivot){
                small++;
                swap(arr, small, i);
            }
        }
        swap(arr, small + 1, r);
        return small + 1;
    }

    public static void mergeSort(int[] arr, int l, int r){
        if(l < r){
            int m = (r + l)/2;
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);
            merge(arr, l, r, m);
        }
    }

    public static void merge(int[] arr, int l, int r, int m){
        int lLen = m - l + 1, rLen = r - m;
        int[] left = new int[lLen], right = new int[rLen];
        for(int i = 0; i < lLen; i++){
            left[i] = arr[l + i];
        }
        for(int j = 0; j < rLen; j++){
            right[j] = arr[m + j + 1];
        }
        int lInd = 0, rInd = 0, k = l;
        while(lInd < lLen && rInd < rLen){
            if(left[lInd] <= right[rInd]){
                arr[k] = left[lInd];
                lInd++;
            }else{
                arr[k] = right[rInd];
                rInd++;
            }
            k++;
        }
        while(lInd < lLen){
            arr[k] = left[lInd];
            lInd++;
            k++;
        }
        while(rInd < rLen){
            arr[k] = right[rInd];
            rInd++;
            k++;
        }
    }

    public static void bubbleSort(int[] arr){
        for(int j = 0; j < arr.length; j++) {
            for (int i = 0; i < arr.length - 1; i++) {
                if (arr[i] > arr[i + 1]) {
                    swap(arr, i, i + 1);
                }
            }
        }
    }


}